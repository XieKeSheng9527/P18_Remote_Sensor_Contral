package com.example.remote;

public class LoginActivity {
}
