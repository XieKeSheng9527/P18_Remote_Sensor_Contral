package com.example.remote;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.rabbitmq.client.CancelCallback;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.DeliverCallback;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    ExecutorService threadPool = Executors.newFixedThreadPool(2);
    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            try {

                ConnectionFactory factory = new ConnectionFactory();
                factory.setHost("192.168.43.183");
                factory.setUsername("admin2");
                factory.setPassword("admin");
                factory.setVirtualHost("admin2");
                factory.setPort(5672);
                Connection connection = factory.newConnection();
                Channel channel = connection.createChannel();
                DeliverCallback deliverCallback = (consumerTag, message) -> {
                    System.out.println("C1:" + new String(message.getBody()));
                    data = new String(message.getBody());
                    String[] d = data.split(",");
                    System.out.println(d[12] + "," + d[14] + "," + d[15]);
                    CO2 = d[12];
                    temperature = d[14];
                    humidity = d[15];


                    //字符切割_仅显示数据
                    String st = CO2;
                    String number = "0123456789";
                    for (int i = 0; i < st.length(); i++) {
                        if (number.indexOf(st.charAt(i)) >= 0) {
                            String s1 = st.substring(i);
                            for (int p = s1.length() - 1; p >= 0; p--) {
                                if (number.indexOf(s1.charAt(p)) >= 0) {
                                    CO2 = s1.substring(0, p + 1) + "  ppm";
                                    break;
                                }
                            }
                            break;
                        }
                    }

                    String stt = temperature;
                    for (int i = 0; i < stt.length(); i++) {
                        if (number.indexOf(stt.charAt(i)) >= 0) {
                            String s1 = stt.substring(i);
                            for (int p = s1.length() - 1; p >= 0; p--) {
                                if (number.indexOf(s1.charAt(p)) >= 0) {
                                    temperature = s1.substring(0, p + 1);
                                    break;
                                }
                            }
                            break;
                        }
                    }

                    String sttt = humidity;
                    for (int i = 0; i < sttt.length(); i++) {
                        if (number.indexOf(sttt.charAt(i)) >= 0) {
                            String s1 = sttt.substring(i);
                            for (int p = s1.length() - 1; p >= 0; p--) {
                                if (number.indexOf(s1.charAt(p)) >= 0) {
                                    humidity = s1.substring(0, p + 1);
                                    break;
                                }
                            }
                            break;
                        }
                    }
                    //字符切割_仅显示数据

                    try {
                        Thread.sleep(50);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                };
                CancelCallback cancelCallback = consumerTag -> {
                    System.out.println("消息被终端");
                };
                channel.basicConsume("sensorData", true, deliverCallback, cancelCallback);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };


    String data = "";
    String CO2 = "";
    String temperature = "";
    String humidity = "";
    //private static ConnectionFactory factory;//本条为后期添加，用于服务器与消费者
    private Thread publishThread;//本条为后期添加，用于与后端对接的尝试
    private Object undefined;
    private TextView tv_1;
    private TextView tv_2;
    private TextView tv_3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //获取按钮
        Button buttonOk = findViewById(R.id.btn);
        //设置按钮点击监听器
        buttonOk.setOnClickListener(new MyOnClickListener());

        tv_1 = (TextView) findViewById(R.id.tv_1);
        tv_2 = (TextView) findViewById(R.id.tv_2);
        tv_3 = (TextView) findViewById(R.id.tv_3);

        //自动点击按钮
        Thread thread = new Thread() {

            @Override
            public void run() {

                try {

                    while (!Thread.currentThread().isInterrupted()) {

                        Thread.sleep(2500);

                        runOnUiThread(new Runnable() {

                            @Override

                            public void run() {

// update TextView here!
                                //获取按钮
                                Button buttonOk = findViewById(R.id.btn);
                                //设置按钮点击监听器
                                buttonOk.setOnClickListener(new MyOnClickListener());
                                buttonOk.performClick();

                                tv_1 = (TextView) findViewById(R.id.tv_1);
                                tv_2 = (TextView) findViewById(R.id.tv_2);
                                tv_3 = (TextView) findViewById(R.id.tv_3);

                            }

                        });

                    }

                } catch (InterruptedException e) {

                }

            }
        };
        thread.start();
        //自动点击按钮

    }


    //定义按钮点击监听器
    class MyOnClickListener implements View.OnClickListener {

        Thread thread = new Thread();

        //按钮点击
        @Override


        public void onClick(View view) {

            if (view.getId() == R.id.btn) {//被点击的是确认按钮

                //获取选中项
                Switch switchMsg = findViewById(R.id.sw);
                String str = "";
                System.out.println("按钮点击");

                //这里这个循环exit自己定义一个变量 来处理退出程序后停止去通道拿消息，否则会爆出异常
                //当断网的时候它会循环去连接通道，直到连接通位置，这里会出现一个问题，如果长时间断网一直去去连接它会不断的创建连接对象，可能会出现内存溢出的情况，自行处理


                if (switchMsg.isChecked() == true) {
                    str = "接收一组新数据";
                    threadPool.execute(runnable);
                    tv_1.setText(temperature);
                    tv_2.setText(humidity);
                    tv_3.setText(CO2);
                    if (data == null) {
                        tv_1.setText("暂无数据可接收");
                        tv_2.setText("暂无数据可接收");
                        tv_3.setText("暂无数据可接收");
                    }
                } else {
                    thread.interrupt();
                    str = "数据通道已关闭";
                }
                //显示提示框
                Toast.makeText(MainActivity.this, str, Toast.LENGTH_SHORT).show();


            }
        }


    }



}