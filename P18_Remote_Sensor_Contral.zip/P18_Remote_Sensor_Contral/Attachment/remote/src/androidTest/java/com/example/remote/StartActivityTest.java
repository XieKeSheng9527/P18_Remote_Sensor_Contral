package com.example.remote;

import junit.framework.TestCase;

public class StartActivityTest extends TestCase {

}