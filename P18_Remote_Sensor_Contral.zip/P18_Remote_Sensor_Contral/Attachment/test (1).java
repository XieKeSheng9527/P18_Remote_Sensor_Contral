package Project;

import Package_Learning.utils.RabbitMQUtils;
import com.rabbitmq.client.*;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

public class test {
    //队列的名称
    public static final String QUEUE_NAME = "sensorData";

    public static void main(String[] args) throws Exception, TimeoutException {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("192.168.43.183");
        factory.setUsername("admin2");
        factory.setPassword("admin");
        factory.setVirtualHost("admin2");
        factory.setPort(5672);
        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();
        //接受消息
        /*
        消费者接收消息
        1.消费哪个队列
        2.消费成功之后是否要自动应答 true代表的是自动应答 false代表的是手动应答
        3.消费者未成功消费的回调
        4消费者取消消费的回调
         */
        //消息的接收
      DeliverCallback deliverCallback = (consumerTag, message) -> {
          String s = new String(message.getBody());
          String[] data =  s.split(",");
          System.out.println(data[12] + "," + data[14] + "," + data[15]);
      };
        //消息接受被取消时 执行下面的内容
        CancelCallback cancelCallback = consumerTag -> System.out.println("消息者取消消费接口回调逻辑");
        channel.basicConsume(QUEUE_NAME, true,deliverCallback,cancelCallback );

    }
}
